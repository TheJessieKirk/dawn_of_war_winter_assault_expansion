----------------------------------------
-- File: 'abilities\sp_dxp_abilities_throw_med.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\sp_dxp_abilities_throw.lua]])
MetaData = InheritMeta([[abilities\sp_dxp_abilities_throw.lua]])

GameData["area_effect"]["area_effect_information"]["radius"] = 5.00000
GameData["area_effect"]["throw_data"]["force_max"] = 60.00000
GameData["area_effect"]["throw_data"]["force_min"] = 40.00000
GameData["area_effect"]["throw_data"]["up_angle_max"] = 60.00000
GameData["area_effect"]["throw_data"]["up_angle_min"] = 25.00000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
