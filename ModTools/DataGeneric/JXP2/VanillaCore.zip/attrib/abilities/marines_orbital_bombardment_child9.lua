----------------------------------------
-- File: 'abilities\marines_orbital_bombardment_child9.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\marines_orbital_bombardment_children.lua]])
MetaData = InheritMeta([[abilities\marines_orbital_bombardment_children.lua]])

GameData["child_ability_name"] = "marines_orbital_bombardment_child10"
GameData["initial_delay_time"] = 23.00000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
