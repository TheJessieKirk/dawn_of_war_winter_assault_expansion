----------------------------------------
-- File: 'abilities\guard_strafing_run_e3demo.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\guard_strafing_run.lua]])
MetaData = InheritMeta([[abilities\guard_strafing_run.lua]])

GameData["ability_motion_name"] = "e3_special_ability_1"
GameData["entity_busy_time"] = 3.03000
GameData["range"] = 100.00000
GameData["requirements"]["required_1"] = Reference([[requirements\required_none.lua]])
GameData["requirements"]["required_10"] = Reference([[requirements\required_none.lua]])


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
