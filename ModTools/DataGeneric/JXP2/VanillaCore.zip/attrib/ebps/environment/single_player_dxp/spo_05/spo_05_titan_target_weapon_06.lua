----------------------------------------
-- File: 'ebps\environment\single_player_dxp\spo_05\spo_05_titan_target_weapon_06.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\single_player_dxp\spo_05\spo_05_titan_target_weapon_01.lua]])
MetaData = InheritMeta([[ebps\environment\single_player_dxp\spo_05\spo_05_titan_target_weapon_01.lua]])

GameData["combat_ext"]["hardpoints"]["hardpoint_01"]["weapon_table"]["weapon_01"]["muzzle"]["x"] = 0.00000
GameData["combat_ext"]["hardpoints"]["hardpoint_01"]["weapon_table"]["weapon_01"]["muzzle"]["y"] = 15.00000
GameData["combat_ext"]["hardpoints"]["hardpoint_01"]["weapon_table"]["weapon_01"]["muzzle"]["z"] = -8.58989
GameData["combat_ext"]["hardpoints"]["hardpoint_01"]["weapon_table"]["weapon_01"]["origin"]["y"] = 15.00000
GameData["combat_ext"]["hardpoints"]["hardpoint_01"]["weapon_table"]["weapon_01"]["weapon"] = "weapon\\npc_titan_maincannon_6.lua"
GameData["entity_blueprint_ext"]["animator"] = "environment\\single_player_dxp\\spo_05\\spo_05_titan_target_weapon_06"
GameData["entity_blueprint_ext"]["scale_y"] = 30.00000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
