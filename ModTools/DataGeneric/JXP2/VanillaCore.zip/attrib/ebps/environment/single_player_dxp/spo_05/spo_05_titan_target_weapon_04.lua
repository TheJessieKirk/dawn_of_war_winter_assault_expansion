----------------------------------------
-- File: 'ebps\environment\single_player_dxp\spo_05\spo_05_titan_target_weapon_04.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\single_player_dxp\spo_05\spo_05_titan_target_weapon_01.lua]])
MetaData = InheritMeta([[ebps\environment\single_player_dxp\spo_05\spo_05_titan_target_weapon_01.lua]])

GameData["combat_ext"]["hardpoints"]["hardpoint_01"]["weapon_table"]["weapon_01"]["muzzle"]["x"] = 8.58989
GameData["combat_ext"]["hardpoints"]["hardpoint_01"]["weapon_table"]["weapon_01"]["weapon"] = "weapon\\npc_titan_maincannon_4.lua"
GameData["entity_blueprint_ext"]["animator"] = "environment\\single_player_dxp\\spo_05\\spo_05_titan_target_weapon_04"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
