----------------------------------------
-- File: 'ebps\environment\single_player_dxp\spo_05\spo_05_titan_arm_01.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\single_player_dxp\spo_05\spo_05.nil]])
MetaData = InheritMeta([[ebps\environment\single_player_dxp\spo_05\spo_05.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment\\single_player_dxp\\spo_05\\spo_05_titan_arm_01"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
