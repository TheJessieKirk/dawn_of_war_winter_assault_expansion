----------------------------------------
-- File: 'ebps\environment\single_player_dxp\spo_03\spo_03_pumphouse_wall_broken_01.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\single_player_dxp\spo_03\spo_03.nil]])
MetaData = InheritMeta([[ebps\environment\single_player_dxp\spo_03\spo_03.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment/single_player_dxp/spo_03/spo_03_pumphouse_wall_broken_01"
GameData["type_ext"]["type_surface"] = Reference([[type_surface\tp_heavy_metal_armour.lua]])


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
