----------------------------------------
-- File: 'ebps\environment\test_fx.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\environment.nil]])
MetaData = InheritMeta([[ebps\environment\environment.nil]])

GameData["entity_blueprint_ext"]["animator"] = "Environment/test_fx"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
