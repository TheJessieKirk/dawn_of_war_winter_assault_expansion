----------------------------------------
-- File: 'ebps\environment\single_player\ms08\chapel_doors_90v2.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\single_player\ms08\chapel_doors.lua]])
MetaData = InheritMeta([[ebps\environment\single_player\ms08\chapel_doors.lua]])

GameData["structure_ext"]["orientation"] = 0.00000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
