----------------------------------------
-- File: 'ebps\environment\snow\fx_snow\fx_snow_hvy_02.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\snow\fx_snow\fx_snow.nil]])
MetaData = InheritMeta([[ebps\environment\snow\fx_snow\fx_snow.nil]])

GameData["entity_blueprint_ext"]["animator"] = "Environment/Snow/fx_snow/Snow_hvy_02"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
