----------------------------------------
-- File: 'ebps\environment\snow\urban_snow\gothic_slums_snow\gothic_slums_snow_03.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\snow\urban_snow\gothic_slums_snow\gothic_slums_snow.nil]])
MetaData = InheritMeta([[ebps\environment\snow\urban_snow\gothic_slums_snow\gothic_slums_snow.nil]])

GameData["entity_blueprint_ext"]["animator"] = "Environment\\Snow\\Urban_snow\\gothic_slums_snow\\gothic_slums_snow_03"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
