----------------------------------------
-- File: 'ebps\environment\snow\urban_snow\interior_snow\staircase_snow_02.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\snow\urban_snow\interior_snow\interior_snow.nil]])
MetaData = InheritMeta([[ebps\environment\snow\urban_snow\interior_snow\interior_snow.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment\\snow\\urban_snow\\interior_snow/staircase_snow_02"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
