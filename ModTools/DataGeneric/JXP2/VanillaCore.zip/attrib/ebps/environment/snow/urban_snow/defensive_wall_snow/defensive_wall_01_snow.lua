----------------------------------------
-- File: 'ebps\environment\snow\urban_snow\defensive_wall_snow\defensive_wall_01_snow.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\snow\urban_snow\defensive_wall_snow\defensive_wall_snow.nil]])
MetaData = InheritMeta([[ebps\environment\snow\urban_snow\defensive_wall_snow\defensive_wall_snow.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment\\snow\\urban_snow\\defensive_wall_snow\\defensive_wall_01_snow"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
