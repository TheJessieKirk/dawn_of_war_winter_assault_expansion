----------------------------------------
-- File: 'ebps\environment\ambient_fx\flare_01.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\ambient_fx\ambient_fx.nil]])
MetaData = InheritMeta([[ebps\environment\ambient_fx\ambient_fx.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment/ambient_fx/flare_01"
GameData["structure_ext"] = Reference([[ebpextensions\structure_ext.lua]])
GameData["ui_ext"] = Reference([[ebpextensions\ui_ext.lua]])


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
MetaData["structure_ext"] = {desc = [[]], type = 4, category = [[]], dispval = [[]], }
MetaData["ui_ext"] = {desc = [[]], type = 4, category = [[]], dispval = [[]], }
