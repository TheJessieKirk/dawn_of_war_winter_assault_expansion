----------------------------------------
-- File: 'ebps\races\guard\troops\guard_vehicles_basilisk_sp_mso2.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\races\guard\troops\guard_vehicles_basilisk.lua]])
MetaData = InheritMeta([[ebps\races\guard\troops\guard_vehicles_basilisk.lua]])

GameData["combat_ext"]["hardpoints"]["hardpoint_01"]["weapon_table"]["weapon_01"]["weapon"] = "weapon\\guard_earthshaker_cannon_basilisk_sp_mso2.lua"
GameData["type_ext"]["single_player_only"] = true


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
