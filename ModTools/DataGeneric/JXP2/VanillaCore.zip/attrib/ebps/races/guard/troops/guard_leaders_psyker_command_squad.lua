----------------------------------------
-- File: 'ebps\races\guard\troops\guard_leaders_psyker_command_squad.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\races\guard\troops\guard_leaders_psyker.lua]])
MetaData = InheritMeta([[ebps\races\guard\troops\guard_leaders_psyker.lua]])

GameData["health_ext"]["hitpoints"] = 250.00000
GameData["requirement_ext"]["requirements"]["required_1"] = Reference([[requirements\required_none.lua]])
GameData["ui_ext"]["ui_info"]["help_text_list"]["text_03"] = "$697350"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, rangeStart = 697350, rangeEnd = 697399, }
MetaData["$METACOLOURTAG"] = 
{

}
