----------------------------------------
-- File: 'ebps\races\eldar\structures\eldar_hq_sp_msoe05.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\races\eldar\structures\eldar_hq.lua]])
MetaData = InheritMeta([[ebps\races\eldar\structures\eldar_hq.lua]])

GameData["structure_buildable_ext"]["advanced_build_option"] = true
GameData["type_ext"]["single_player_only"] = true


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
