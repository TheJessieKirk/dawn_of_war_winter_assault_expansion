----------------------------------------
-- File: 'ebps\races\npc\troops\guard_megaship.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\races\npc\troops\npc_troop.nil]])
MetaData = InheritMeta([[ebps\races\npc\troops\npc_troop.nil]])

GameData["entity_blueprint_ext"]["animator"] = "\\Races\\npc\\Troops\\Guard_MegaShip"
GameData["health_ext"]["hitpoints"] = 1.00000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
