----------------------------------------
-- File: 'ebps\game\projectiles\ork_dual_rokkit.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\game\projectiles\ork_rokkit.lua]])
MetaData = InheritMeta([[ebps\game\projectiles\ork_rokkit.lua]])

GameData["entity_blueprint_ext"]["animator"] = "races/orks/projectiles/ork_dual_rokkit"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
