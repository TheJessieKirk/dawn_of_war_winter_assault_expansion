----------------------------------------
-- File: 'ebps\game\relocation\relocate_supportplatform.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\game\relocation\relocation_structures.nil]])
MetaData = InheritMeta([[ebps\game\relocation\relocation_structures.nil]])

GameData["entity_blueprint_ext"]["animator"] = "Races/Eldar/Structures/support_platform"
GameData["entity_blueprint_ext"]["scale_z"] = 2.00000
GameData["structure_ext"]["control_structure_use"] = true
GameData["structure_ext"]["control_structure_use_allied"] = true
GameData["structure_ext"]["extra_no_build_buffer"] = 1.00000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
